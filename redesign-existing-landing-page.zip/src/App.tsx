import { useEffect, useRef, useState, type ReactNode } from "react";

const CHECKOUT = "https://pay.cakto.com.br/4derups_1188495";
const BASE = "https://metodolp.voltenbr.workers.dev/assets";
const VAGAS = 45;
const TOTAL = 100;

/* ---------- helpers ---------- */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && (e.target.classList.add("in"), io.unobserve(e.target))),
      { threshold: 0.12 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function useCountdown() {
  const [left, setLeft] = useState(0);
  useEffect(() => {
    const KEY = "mlp_deadline";
    let end = Number(localStorage.getItem(KEY));
    if (!end || end < Date.now()) {
      end = Date.now() + 1000 * 60 * 60 * 2 + 1000 * 60 * 17;
      localStorage.setItem(KEY, String(end));
    }
    const t = setInterval(() => setLeft(Math.max(0, end - Date.now())), 1000);
    setLeft(Math.max(0, end - Date.now()));
    return () => clearInterval(t);
  }, []);
  const h = Math.floor(left / 3600000);
  const m = Math.floor((left % 3600000) / 60000);
  const s = Math.floor((left % 60000) / 1000);
  return [h, m, s].map((n) => String(n).padStart(2, "0"));
}

const Check = ({ className = "" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" className={`h-5 w-5 shrink-0 ${className}`} fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 6 9 17l-5-5" />
  </svg>
);
const XIcon = ({ className = "" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" className={`h-5 w-5 shrink-0 ${className}`} fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round">
    <path d="M18 6 6 18M6 6l12 12" />
  </svg>
);
const Arrow = () => (
  <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
    <path d="M5 12h14M13 5l7 7-7 7" />
  </svg>
);
const Lock = () => (
  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2.5}>
    <rect x="4" y="11" width="16" height="10" rx="2" />
    <path d="M8 11V7a4 4 0 0 1 8 0v4" />
  </svg>
);

function CTA({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <a href={CHECKOUT} target="_blank" rel="noopener" className={`btn-neon px-8 py-5 text-lg ${className}`}>
      <span className="relative z-10">{children}</span>
      <span className="relative z-10"><Arrow /></span>
    </a>
  );
}

function Tag({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-neon/30 bg-neon/10 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-neon">
      <span className="h-1.5 w-1.5 rounded-full bg-neon shadow-[0_0_8px_#3dff1a]" />
      {children}
    </span>
  );
}

function Section({ id, children, className = "" }: { id?: string; children: ReactNode; className?: string }) {
  return (
    <section id={id} className={`relative overflow-hidden px-5 py-20 md:py-28 ${className}`}>
      <div className="mx-auto max-w-6xl">{children}</div>
    </section>
  );
}

function Title({ tag, children, sub }: { tag?: string; children: ReactNode; sub?: ReactNode }) {
  return (
    <div className="reveal mx-auto mb-14 max-w-3xl text-center">
      {tag && <Tag>{tag}</Tag>}
      <h2 className="mt-5 text-3xl font-extrabold leading-[1.1] tracking-tight md:text-5xl">{children}</h2>
      {sub && <p className="mx-auto mt-5 max-w-2xl text-lg text-muted">{sub}</p>}
    </div>
  );
}

/* ---------- sections ---------- */
function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const on = () => {
      setScrolled(window.scrollY > 40);
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(h > 0 ? window.scrollY / h : 0);
    };
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <>
      <div className="fixed left-0 top-0 z-[60] h-1 w-full origin-left bg-neon shadow-[0_0_14px_#3dff1a]" style={{ transform: `scaleX(${progress})` }} />
      <header className="fixed inset-x-0 top-0 z-50">
        <TopBar />
        <div className={`transition-all duration-300 ${scrolled ? "border-b border-line bg-bg/80 py-3 backdrop-blur-xl" : "py-4"}`}>
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5">
          <a href="#" className="flex items-center gap-2 text-xl font-extrabold tracking-tight">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-neon text-sm font-black text-bg shadow-[0_0_20px_rgba(61,255,26,.5)]">LP</span>
            Método<span className="text-neon">LP</span>
          </a>
          <nav className="hidden items-center gap-8 text-sm font-semibold text-muted md:flex">
            <a href="#metodo" className="hover:text-neon">O método</a>
            <a href="#conteudo" className="hover:text-neon">Conteúdo</a>
            <a href="#depoimentos" className="hover:text-neon">Depoimentos</a>
            <a href="#faq" className="hover:text-neon">Dúvidas</a>
          </nav>
          <a href="#oferta" className={`rounded-xl bg-neon px-5 py-2.5 text-sm font-extrabold text-bg transition-all hover:scale-105 ${scrolled ? "opacity-100" : "opacity-0 md:opacity-100"}`}>
            Quero acesso
          </a>
        </div>
        </div>
      </header>
    </>
  );
}

function TopBar() {
  const [h, m, s] = useCountdown();
  return (
    <div className="relative z-[55] bg-neon px-4 py-2 text-center text-xs font-bold text-bg sm:text-sm">
      🔥 Oferta de lançamento: <span className="underline">R$ 49,90</span> termina em{" "}
      <span className="font-mono tabular-nums">{h}:{m}:{s}</span>
    </div>
  );
}

function Hero() {
  const words = "Crie landing pages e sites profissionais do zero,".split(" ");
  return (
    <section className="relative isolate flex min-h-[100svh] items-center overflow-hidden px-5 pb-16 pt-40">
      <div className="absolute inset-0 -z-30">
        <img src={`${BASE}/foto.webp`} alt="" className="zoomout h-full w-full object-cover object-[78%_18%]" />
      </div>
      <div className="absolute inset-0 -z-20 bg-[linear-gradient(90deg,#050a06_8%,rgba(5,10,6,.85)_45%,rgba(5,10,6,.35)_100%)] max-md:bg-[linear-gradient(180deg,rgba(5,10,6,.55)_0%,rgba(5,10,6,.9)_55%,#050a06_100%)]" />
      <div className="absolute inset-x-0 bottom-0 -z-20 h-40 bg-gradient-to-t from-bg to-transparent" />
      <div className="grid-bg absolute inset-0 -z-10" />
      <div className="absolute -left-40 top-1/4 -z-10 h-[500px] w-[500px] rounded-full bg-neon/20 blur-[120px]" />

      <div className="mx-auto w-full max-w-6xl">
        <div className="max-w-2xl">
          <Tag>Curso 100% prático · Para iniciantes</Tag>
          <h1 className="mt-6 text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-5xl md:text-6xl">
            {words.map((w, i) => (
              <span key={i} className="inline-block opacity-0 [animation:fadeUp_.6s_forwards]" style={{ animationDelay: `${i * 0.07}s` }}>
                {w}&nbsp;
              </span>
            ))}
            <span className="shine inline-block">sem programar</span> e{" "}
            <span className="shine inline-block">sem comprar domínio.</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-ink/90 md:text-xl">
            Use no seu negócio ou <strong className="text-neon2">venda páginas para clientes</strong>. Um passo a passo simples para tirar sua página do papel e colocá-la no ar, mesmo começando do zero.
          </p>

          <div className="mt-9 flex flex-col items-start gap-5 sm:flex-row sm:items-center">
            <CTA>Quero aprender o Método LP</CTA>
            <div className="text-sm">
              <div className="text-muted">De <s>R$ 129,90</s> por</div>
              <div className="text-2xl font-extrabold text-neon">R$ 49,90</div>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm text-muted">
            {["Acesso imediato", "Pagamento seguro", "7 dias de garantia"].map((t) => (
              <span key={t} className="flex items-center gap-2"><Check className="h-4 w-4 text-neon" />{t}</span>
            ))}
          </div>
        </div>
      </div>
      <style>{`@keyframes fadeUp{from{opacity:0;transform:translateY(30px);filter:blur(8px)}to{opacity:1;transform:none;filter:blur(0)}}`}</style>
    </section>
  );
}

function Marquee() {
  const items = ["Sem código", "Sem domínio", "Sem mensalidade", "Do zero ao ar", "Venda para clientes", "Passo a passo", "Acesso imediato", "Garantia de 7 dias"];
  const row = [...items, ...items];
  return (
    <div className="relative -rotate-1 border-y border-neon/30 bg-neon py-4 text-bg">
      <div className="marquee flex w-max gap-10 whitespace-nowrap text-lg font-extrabold uppercase tracking-wide">
        {row.map((t, i) => (
          <span key={i} className="flex items-center gap-10">{t}<span>✦</span></span>
        ))}
      </div>
    </div>
  );
}

function Pains() {
  const pains = [
    ["💡", "Você tem uma ideia ou um negócio, mas", "não tem uma página", "para apresentá-lo."],
    ["💸", "Orçamentos de programador e designer", "custam caro", "e demoram semanas."],
    ["🌀", "Tentou aprender sozinho e se perdeu em", "dezenas de tutoriais soltos", "no YouTube."],
    ["🧱", "Acha que precisa", "saber programar ou pagar domínio", "antes de começar."],
    ["🤔", "Vê outras pessoas", "cobrando por páginas", "e pensa: “Por que não eu?”"],
  ];
  return (
    <Section>
      <Title tag="Seja sincero">Você se identifica com isso?</Title>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {pains.map(([e, a, b, c], i) => (
          <div key={i} className={`reveal card-glow rounded-2xl p-6 ${i === 4 ? "md:col-span-2 lg:col-span-1" : ""}`} style={{ transitionDelay: `${i * 80}ms` }}>
            <div className="mb-4 grid h-12 w-12 place-items-center rounded-xl bg-neon/10 text-2xl">{e}</div>
            <p className="text-lg leading-relaxed text-ink/90">
              {a} <strong className="text-neon2">{b}</strong> {c}
            </p>
          </div>
        ))}
      </div>
      <div className="reveal mx-auto mt-12 max-w-2xl rounded-2xl border border-neon/40 bg-neon/5 p-6 text-center text-xl font-bold md:text-2xl">
        O problema não é você. <span className="text-neon">É que ninguém te mostrou um caminho simples.</span>
      </div>
    </Section>
  );
}

function Method() {
  const steps = [
    ["01", "Estruture", "Defina o objetivo e o layout da página antes de colocar a mão na massa.", "🧭"],
    ["02", "Construa", "Monte a página visualmente, arrastando e editando. Zero código.", "🛠️"],
    ["03", "Publique", "Coloque no ar sem comprar domínio e sem pagar hospedagem.", "🚀"],
    ["04", "Replique", "Use o mesmo método para criar quantas páginas quiser, para você ou clientes.", "♻️"],
  ];
  return (
    <Section id="metodo" className="bg-panel/50">
      <div className="grid-bg pointer-events-none absolute inset-0" />
      <Title tag="Apresentamos" sub="Um método prático, em passos claros, que ensina a criar landing pages e páginas web do zero. Você segue o método, e ele faz o trabalho pesado.">
        O <span className="shine">Método LP</span> em 4 passos
      </Title>
      <div className="relative grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        <div className="absolute left-0 right-0 top-[52px] hidden h-px bg-gradient-to-r from-transparent via-neon/50 to-transparent lg:block" />
        {steps.map(([n, t, d, e], i) => (
          <div key={n} className="reveal card-glow relative rounded-2xl p-7" style={{ transitionDelay: `${i * 120}ms` }}>
            <div className="mb-5 flex items-center justify-between">
              <span className="grid h-12 w-12 place-items-center rounded-full bg-neon font-black text-bg shadow-[0_0_24px_rgba(61,255,26,.5)]">{n}</span>
              <span className="text-3xl">{e}</span>
            </div>
            <h3 className="text-2xl font-extrabold">{t}</h3>
            <p className="mt-2 text-muted">{d}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

function VideoBlock() {
  const ref = useRef<HTMLVideoElement>(null);
  const [muted, setMuted] = useState(true);
  const toggle = () => {
    const v = ref.current;
    if (!v) return;
    v.muted = !v.muted;
    if (!v.muted) { v.currentTime = 0; v.play(); }
    setMuted(v.muted);
  };
  return (
    <Section>
      <Title tag="Veja por dentro">Assista e entenda como funciona</Title>
      <div className="reveal relative mx-auto max-w-sm">
        <div className="absolute -inset-6 rounded-[40px] bg-neon/20 blur-3xl" />
        <div className="relative overflow-hidden rounded-[28px] border-2 border-neon/50 bg-black shadow-[0_30px_80px_rgba(0,0,0,.6)]">
          <video ref={ref} src={`${BASE}/video.mp4`} autoPlay muted loop playsInline preload="metadata" onClick={toggle} className="aspect-[9/16] w-full cursor-pointer object-cover" />
          {muted && (
            <button onClick={toggle} className="absolute inset-0 grid place-items-center bg-black/30">
              <span className="flex items-center gap-2 rounded-full bg-neon px-5 py-3 font-extrabold text-bg shadow-lg">
                🔊 Toque para ativar o som
              </span>
            </button>
          )}
        </div>
      </div>
    </Section>
  );
}

function Deliverables() {
  const items = [
    ["🎬", "Método LP: aulas em vídeo", "Passo a passo prático para criar sua primeira página do zero e publicá-la.", "R$ 97"],
    ["🧰", "Ferramentas para criação", "Recursos que aceleram o processo e economizam horas de trabalho.", "R$ 47"],
    ["📘", "PDF de apoio", "Material de suporte detalhado para consultar sempre que precisar.", "R$ 27"],
    ["🎁", "Bônus exclusivo", "Conteúdo complementar de alto valor, liberado junto com o acesso.", "R$ 37"],
  ];
  return (
    <Section id="conteudo" className="bg-panel/50">
      <Title tag="O que você recebe">Tudo que você recebe no <span className="shine">Método LP</span></Title>
      <div className="grid gap-5 md:grid-cols-2">
        {items.map(([e, t, d, v], i) => (
          <div key={t} className="reveal card-glow flex gap-5 rounded-2xl p-6 md:p-7" style={{ transitionDelay: `${i * 100}ms` }}>
            <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl border border-neon/30 bg-neon/10 text-3xl">{e}</div>
            <div className="flex-1">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <h3 className="text-xl font-extrabold">{t}</h3>
                <span className="rounded-md bg-line px-2 py-0.5 text-xs font-bold text-muted line-through">{v}</span>
              </div>
              <p className="mt-2 text-muted">{d}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="reveal mt-10 flex flex-col items-center gap-4 text-center">
        <p className="text-muted">Valor total: <s>R$ 208,00</s> · Hoje por apenas <strong className="text-2xl text-neon">R$ 49,90</strong></p>
        <CTA>Quero tudo isso agora</CTA>
      </div>
    </Section>
  );
}

function Benefits() {
  const b = [
    ["🔓", "Independência total", "Pare de depender de terceiros. Crie as páginas do seu negócio na hora que precisar."],
    ["💰", "Uma nova fonte de renda", "Aprenda a criar páginas que clientes pagam para ter. Um método, vários projetos."],
    ["⚡", "Economia e velocidade", "Sem programador, sem domínio e sem mensalidades para começar. Do zero ao ar com rapidez."],
  ];
  return (
    <Section>
      <Title tag="Transformação">O que muda para você</Title>
      <div className="grid gap-5 md:grid-cols-3">
        {b.map(([e, t, d], i) => (
          <div key={t} className="reveal card-glow group rounded-3xl p-8 text-center" style={{ transitionDelay: `${i * 120}ms` }}>
            <div className="floaty mx-auto mb-6 grid h-20 w-20 place-items-center rounded-full bg-gradient-to-br from-neon/30 to-transparent text-4xl ring-1 ring-neon/30" style={{ animationDelay: `${i * 0.5}s` }}>{e}</div>
            <h3 className="text-2xl font-extrabold">{t}</h3>
            <p className="mt-3 text-muted">{d}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

function ForWhom() {
  const list = [
    "Nunca programou e quer começar do zero, sem complicação.",
    "Tem um produto, serviço ou negócio e precisa de uma página para divulgar.",
    "Quer oferecer a criação de páginas como serviço para outras pessoas.",
    "Está cansado de depender de terceiros para colocar uma página no ar.",
  ];
  return (
    <Section className="bg-panel/50">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <div className="reveal">
          <Tag>Perfil ideal</Tag>
          <h2 className="mt-5 text-3xl font-extrabold leading-tight md:text-5xl">Esse método é <span className="shine">para você</span> se...</h2>
          <ul className="mt-8 space-y-4">
            {list.map((t) => (
              <li key={t} className="flex gap-4 rounded-xl border border-line bg-bg/50 p-4 text-lg">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-neon text-bg"><Check className="h-4 w-4" /></span>
                {t}
              </li>
            ))}
          </ul>
        </div>
        <div className="reveal grid gap-5">
          <div className="rounded-3xl border border-red-500/30 bg-red-500/5 p-7">
            <div className="mb-4 flex items-center gap-3 text-lg font-extrabold text-red-400"><XIcon /> Sem o método</div>
            <ul className="space-y-2 text-muted">
              <li>• Horas perdidas em vídeos soltos</li>
              <li>• Dúvida em cada passo</li>
              <li>• Gastos com programador, domínio e hospedagem</li>
              <li>• Página que nunca sai do papel</li>
            </ul>
          </div>
          <div className="relative rounded-3xl border-2 border-neon bg-neon/10 p-7 shadow-[0_0_50px_rgba(61,255,26,.15)]">
            <span className="absolute -top-3 right-6 rounded-full bg-neon px-3 py-1 text-xs font-black uppercase text-bg">Recomendado</span>
            <div className="mb-4 flex items-center gap-3 text-lg font-extrabold text-neon"><Check /> Com o método</div>
            <ul className="space-y-2 text-ink/90">
              <li>• Caminho claro do zero à publicação</li>
              <li>• Ferramentas e PDF para não travar</li>
              <li>• Custo zero para colocar no ar</li>
              <li>• Página publicada em uma tarde</li>
            </ul>
          </div>
        </div>
      </div>
    </Section>
  );
}

type Msg = { me?: boolean; t: string; time: string };
function Chat({ name, status, msgs, color }: { name: string; status: string; msgs: Msg[]; color: string }) {
  return (
    <div className="reveal overflow-hidden rounded-3xl border border-line bg-[#0b141a] shadow-2xl">
      <div className="flex items-center gap-3 bg-[#1f2c34] px-4 py-3">
        <div className={`grid h-10 w-10 place-items-center rounded-full font-bold text-white ${color}`}>{name[0]}</div>
        <div>
          <div className="font-semibold text-white">{name}</div>
          <div className="text-xs text-[#8696a0]">{status}</div>
        </div>
      </div>
      <div className="space-y-2 bg-[#0b141a] bg-[radial-gradient(rgba(255,255,255,.03)_1px,transparent_1px)] p-4 [background-size:16px_16px]">
        {msgs.map((m, i) => (
          <div key={i} className={`flex ${m.me ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[85%] rounded-xl px-3 py-2 text-[15px] leading-snug text-[#e9edef] ${m.me ? "rounded-tr-sm bg-[#005c4b]" : "rounded-tl-sm bg-[#202c33]"}`}>
              {m.t}
              <span className="ml-2 inline-block translate-y-1 text-[10px] text-[#8696a0]">{m.time}{m.me && " ✓✓"}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Testimonials() {
  return (
    <Section id="depoimentos">
      <Title tag="Prova social" sub="Mensagens reais de alunos que aplicaram o passo a passo.">Quem aplicou, <span className="shine">aprovou</span></Title>
      <div className="grid gap-6 md:grid-cols-3">
        <Chat name="Rafael" status="online" color="bg-emerald-600" msgs={[
          { t: "Mano, acabei de publicar minha primeira página kkkk. Não acredito que consegui sem saber nada de código", time: "14:02" },
          { me: true, t: "Boa demais! Ficou show, parabéns 👏", time: "14:05" },
          { t: "As aulas são muito diretas, fui seguindo o passo a passo e deu certo de primeira 🔥", time: "14:06" },
        ]} />
        <Chat name="Juliana" status="online" color="bg-pink-600" msgs={[
          { t: "Oi! Passando pra agradecer. O PDF de apoio me salvou, tirei todas as dúvidas nele", time: "09:41" },
          { t: "Já estou montando a página do meu negócio 😍", time: "09:42" },
          { me: true, t: "Que massa, Ju! Qualquer coisa me chama 🚀", time: "09:50" },
        ]} />
        <Chat name="Thiago" status="visto por último hoje" color="bg-sky-600" msgs={[
          { t: "Valeu demais pelo método, melhor R$ 49 que já gastei", time: "21:15" },
          { t: "As ferramentas aceleraram muito, em uma tarde minha landing já estava no ar", time: "21:16" },
          { me: true, t: "Fico feliz demais! Bora vender 💪", time: "21:20" },
        ]} />
      </div>
    </Section>
  );
}

function Offer() {
  const [h, m, s] = useCountdown();
  const pct = ((TOTAL - VAGAS) / TOTAL) * 100;
  const incl = ["Aulas em vídeo do zero à publicação", "Ferramentas para acelerar a criação", "PDF de apoio completo", "Bônus exclusivo", "Acesso imediato por e-mail", "7 dias de garantia incondicional"];
  return (
    <Section id="oferta" className="bg-panel/50">
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[700px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-neon/10 blur-[140px]" />
      <div className="reveal relative mx-auto max-w-xl">
        <div className="absolute -inset-px rounded-[32px] bg-gradient-to-b from-neon via-neon/30 to-neon/0" />
        <div className="relative rounded-[31px] bg-bg p-7 md:p-10">
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-neon px-5 py-1.5 text-sm font-black uppercase text-bg">Oferta de lançamento</div>
          <h3 className="mt-3 text-center text-2xl font-extrabold">Método LP completo</h3>

          <ul className="mt-6 space-y-3">
            {incl.map((t) => (
              <li key={t} className="flex items-center gap-3"><Check className="text-neon" />{t}</li>
            ))}
          </ul>

          <div className="my-8 border-t border-dashed border-line" />

          <div className="text-center">
            <div className="text-muted">De <s>R$ 129,90</s> por apenas</div>
            <div className="mt-1 flex items-start justify-center gap-1 font-extrabold">
              <span className="mt-3 text-2xl">R$</span>
              <span className="shine text-7xl leading-none md:text-8xl">49</span>
              <span className="mt-3 text-3xl">,90</span>
            </div>
            <div className="mt-2 text-sm text-muted">Pagamento único · Sem mensalidade</div>
          </div>

          <div className="mt-7 rounded-2xl border border-line bg-panel p-4">
            <div className="mb-2 flex justify-between text-sm font-semibold">
              <span>Vagas restantes: <span className="text-neon">{VAGAS}</span></span>
              <span className="text-muted">{TOTAL - VAGAS}/{TOTAL} preenchidas</span>
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-line">
              <div className="h-full rounded-full bg-gradient-to-r from-neon2 to-neon shadow-[0_0_12px_#3dff1a]" style={{ width: `${pct}%` }} />
            </div>
            <div className="mt-3 flex items-center justify-center gap-2 text-sm text-muted">
              Preço sobe em
              {[h, m, s].map((v, i) => (
                <span key={i} className="rounded-md bg-bg px-2 py-1 font-mono font-bold tabular-nums text-neon">{v}</span>
              ))}
            </div>
          </div>

          <CTA className="mt-7 w-full">Garantir minha vaga</CTA>
          <div className="mt-4 flex items-center justify-center gap-2 text-sm text-muted">
            <Lock /> Pagamento seguro pela Cakto · Pix e Cartão
          </div>
        </div>
      </div>
    </Section>
  );
}

function Guarantee() {
  return (
    <Section>
      <div className="reveal mx-auto flex max-w-4xl flex-col items-center gap-10 rounded-3xl border border-line bg-gradient-to-br from-panel to-bg p-8 md:flex-row md:p-12">
        <div className="relative grid h-48 w-48 shrink-0 place-items-center">
          <svg viewBox="0 0 200 200" className="spin-slow absolute inset-0 h-full w-full">
            <defs><path id="c" d="M100,100 m-80,0 a80,80 0 1,1 160,0 a80,80 0 1,1 -160,0" /></defs>
            <text className="fill-neon text-[15px] font-bold uppercase tracking-[.3em]"><textPath href="#c">★ Garantia incondicional ★ Risco zero ★</textPath></text>
          </svg>
          <div className="grid h-32 w-32 place-items-center rounded-full bg-neon text-center text-bg shadow-[0_0_50px_rgba(61,255,26,.4)]">
            <div><div className="text-5xl font-black leading-none">7</div><div className="text-xs font-extrabold uppercase">dias</div></div>
          </div>
        </div>
        <div className="text-center md:text-left">
          <h2 className="text-3xl font-extrabold md:text-4xl">Seu risco é <span className="text-neon">zero</span></h2>
          <p className="mt-4 text-lg text-muted">Entre, assista às aulas e teste. Se não for o que você esperava, peça o reembolso em até 7 dias após a compra e devolvemos <strong className="text-ink">100% do seu dinheiro</strong>. Sem perguntas, sem burocracia.</p>
        </div>
      </div>
    </Section>
  );
}

function FAQ() {
  const faqs = [
    ["Nunca mexi com isso. Consigo aprender?", "Sim. O método foi pensado para iniciantes, com passo a passo do zero, sem termos técnicos complicados."],
    ["Preciso saber programar?", "Não. Tudo é feito de forma visual, sem escrever uma linha de código."],
    ["Preciso comprar domínio ou hospedagem?", "Não para começar. O método mostra como publicar sua página sem esse custo inicial."],
    ["Dá para vender páginas para outras pessoas?", "Sim. O método ensina a criar páginas repetíveis, que você pode usar para clientes. Os resultados dependem da sua dedicação e da sua oferta."],
    ["E se eu não gostar?", "Você tem 7 dias de garantia. Se não fizer sentido, devolvemos 100% do valor."],
    ["Como recebo o acesso?", "Logo após a confirmação do pagamento, o acesso chega para você por e-mail."],
    ["Quais formas de pagamento?", "As opções aparecem na tela de pagamento seguro da Cakto, ao clicar no botão de compra."],
    ["O valor de R$ 49,90 vai subir?", "Sim. O preço promocional vale para os primeiros 100 alunos. Depois, o valor volta para R$ 129,90."],
  ];
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Section id="faq" className="bg-panel/50">
      <Title tag="Dúvidas">Perguntas frequentes</Title>
      <div className="mx-auto max-w-3xl space-y-3">
        {faqs.map(([q, a], i) => {
          const isOpen = open === i;
          return (
            <div key={q} className={`reveal overflow-hidden rounded-2xl border transition-colors ${isOpen ? "border-neon/60 bg-neon/5" : "border-line bg-bg/60"}`}>
              <button onClick={() => setOpen(isOpen ? null : i)} className="flex w-full items-center justify-between gap-4 p-5 text-left text-lg font-bold">
                {q}
                <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-full border border-neon/40 text-neon transition-transform duration-300 ${isOpen ? "rotate-45 bg-neon text-bg" : ""}`}>+</span>
              </button>
              <div className={`grid transition-all duration-300 ${isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}>
                <div className="overflow-hidden"><p className="px-5 pb-5 text-muted">{a}</p></div>
              </div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}

function FinalCTA() {
  return (
    <Section>
      <div className="grid-bg pointer-events-none absolute inset-0" />
      <div className="reveal relative mx-auto max-w-3xl text-center">
        <h2 className="text-4xl font-extrabold leading-tight md:text-6xl">Sua primeira página no ar <span className="shine">começa hoje.</span></h2>
        <p className="mx-auto mt-6 max-w-xl text-lg text-muted">
          Restam <strong className="text-neon">{VAGAS} vagas</strong> por <strong className="text-ink">R$ 49,90</strong>. Depois, volta para R$ 129,90.
        </p>
        <CTA className="mt-10">Quero começar agora</CTA>
        <div className="mt-6 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-muted">
          <span>🔒 Compra segura</span><span>⚡ Acesso imediato</span><span>🛡️ Garantia de 7 dias</span>
        </div>
      </div>
    </Section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-line px-5 pb-28 pt-10 text-center text-sm text-muted md:pb-10">
      <div className="mb-2 font-extrabold text-ink">Método<span className="text-neon">LP</span></div>
      © {new Date().getFullYear()} Método LP. Todos os direitos reservados.
      <p className="mx-auto mt-3 max-w-2xl text-xs opacity-70">Os resultados variam de pessoa para pessoa e dependem da dedicação e aplicação de cada aluno.</p>
    </footer>
  );
}

function StickyMobile() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const on = () => setShow(window.scrollY > window.innerHeight * 0.8);
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <div className={`fixed inset-x-0 bottom-0 z-50 border-t border-line bg-bg/90 p-3 backdrop-blur-xl transition-transform duration-300 md:hidden ${show ? "translate-y-0" : "translate-y-full"}`}>
      <div className="flex items-center gap-3">
        <div className="leading-tight">
          <div className="text-xs text-muted line-through">R$ 129,90</div>
          <div className="text-xl font-extrabold text-neon">R$ 49,90</div>
        </div>
        <a href={CHECKOUT} target="_blank" rel="noopener" className="btn-neon flex-1 py-3.5 text-base">
          <span className="relative z-10">Garantir vaga</span>
        </a>
      </div>
    </div>
  );
}

export default function App() {
  useReveal();
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <Marquee />
      <Pains />
      <Method />
      <VideoBlock />
      <Deliverables />
      <Benefits />
      <ForWhom />
      <Testimonials />
      <Offer />
      <Guarantee />
      <FAQ />
      <FinalCTA />
      <Footer />
      <StickyMobile />
    </div>
  );
}
